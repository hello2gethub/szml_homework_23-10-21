// TS

// 联合类型表示取值可以为多种类型中的一种
// let myData: string | number;
// myData = 'str';
// myData = 1;









