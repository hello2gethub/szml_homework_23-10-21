// TS类型断言

// “尖括号”语法
// let someValue1: unknown = 'this is string';
// // let strLength1: number = someValue1.length;
// // let strLength1: number = (<string>someValue1).length;

// // // as 语法
// let someValue2: unknown = 'this is string';
// let strLength2: number = (someValue2 as string).length;

// // 非空断言
// let dom = document.getElementById('root');
// dom!.style.color = 'red';

