// TS基础类型
// null、undefined、object

// 默认情况下null和undefined是其他类型的子类型

// let u:undefined = undefined;
// let n: null = null;
// let str: string;
// str = 'abc';
// str = null;
// str = undefined;

// // object类型
// let obj:object= {a: 1}
// obj = new Date();
// obj = null;



