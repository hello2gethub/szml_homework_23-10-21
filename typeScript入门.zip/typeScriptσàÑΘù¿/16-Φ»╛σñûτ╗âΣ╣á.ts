// TS

// 通过继承和派生使得Bird类的实例有fly和move方法
// interface Flyabel {
// fly: () => void;
// }

// class Animal {
// move() {
//     console.log('move')
// }
// }

// class Bird{}
// const bird = new Bird()

// bird.fly();
// bird.move();










