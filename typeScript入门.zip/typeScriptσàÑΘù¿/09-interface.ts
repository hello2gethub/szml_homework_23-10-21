// TS
// interface 接口 行为的抽象，可以用来约束一个函数、对象、以及类的结构和类型

// interface Fn {
//     (a: string): void
// }

// const f1:Fn = () => {}


// // 约束对象
// interface Person {
//     name: string;
//     age: number;
//     [key: string]: any, //索引签名
// }

// const p1:Person = {
//     name:'',
//     age: 10,
//     a: [] || null,
//     b: undefined,
//     c: 100,
// }


// 约束类
// interface Person1 {
//     run(): boolean;
// }

// class Child implements Person1 {
//     run() {
//         return false;
//     }
// }

// const child = new Child()
// child.run();




