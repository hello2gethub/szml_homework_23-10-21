// // TS
// // type 类型别名

// type Id = string | number;
// let id: Id = 1;
// id = 'a';

// type Point = {
//     x: number;
//     y: number;
// }

// const p2:Point = {
//     x: 1,
//     y: 1,
// }

// type SetPoint = (x: number,y: number) => void;
// const fn:SetPoint = () => {}
// // fn(1,2)

// // 约束类
// type Person1 = {
//     run(): boolean;
// }

// class Child implements Person1 {
//     run() {
//         return false;
//     }
// }


// // 思考：type 和 interface的区别




