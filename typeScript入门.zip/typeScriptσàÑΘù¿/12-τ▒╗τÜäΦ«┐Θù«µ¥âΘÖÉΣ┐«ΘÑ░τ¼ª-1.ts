// TS
// public  默认权限，全部都可以访问
// private 只能在当前类中使用

// class Animal {
//     private name: string;
//     public constructor(theName: string) {
//         this.name = theName;
//     }
//     public move(distance: number) {
//         console.log(`${this.name} moved ${distance}m`);
//     }
// }

// const cat = new Animal('Cat');
// console.log(cat.name); // 私有属性无法访问
// console.log(cat.move(2)); //共有属性可以访问











