// TS
// readOnly

// class Person {
//     readonly name: string;
//     constructor(theName: string) {
//         this.name = theName;
//     }
// }

// const jake = new Person('jake');
// jake.name = 'tom'; //无法为“name”赋值










